#!/usr/bin/perl
#Written by Nathan Bachmann (nathan.bachmann@uqconnect.edu.au) under the supervision of Dr Scott Beatson
#(s.beatson@uq.edu.au) on the 6/05/12

use warnings;
use strict;
use lib (glob('~/lib'));
use effectorfamperlmodule;

my $usage = <<'USAGE';

USAGE:

effectorfam_serach.pl <Sequence_file> <Path to EffectorFAMdb>

Runs effectorFAM on a sequence file to search for and annotate Type III effector protein.

Sequence file can be multifasta file of protein sequences or a nucleotide fasta sequence file of 
genome.

Current status: Beta version 0.1

For support and inquires: nathan.bachmann@uqconnect.edu.au

USAGE

#variable list
my @part;
my $line1;
my $aa;
my $seq;
my $protein;
my $cds;
my $result;
my $line2;
my $line3;
my $gene;
my $data;
my $eValue;
my $bitScore;
my $eValueDom;
my $N;
my $hmm;
my $anno;
my @effectorfam_res;
my $check;
my $check2 = "0";
my $check3;
my %hash;
my %hash2;
my $model;
my $desc;
my $aliFrom;
my $aliTo;

my $path = $ARGV[1];


#print the usage if no files are entered
unless (defined ($ARGV[0]))
{
	print $usage;
	exit;
}

my $filename = $ARGV[0];

#checks to see if the input file is nucleic acid
open (IN2, "$filename") or die "Couldn't open $filename";

foreach $line1 (<IN2>)
{
	chomp $line1;
	if ($line1 =~ ">")
	{
		next;
	}
	elsif ($line1 =~ /\W/)
	{
		print "Error invalid character in input file\n";
		exit;
	}
	elsif ($line1 =~ /[efilpqz]/i) #bdefhiklmpqrsvyz
	{
		$aa = 'T';
		last;
	}
	else
	{
		$aa = 'F';
		$seq .= $line1;
	}
}

#if sequnce is nucleic acid then translate
if ($aa =~ 'F')
{
	print "Translating the nucleic acid sequence.\n";
	print "This may take several minutes.\n";
	open (OUT2, ">enterdata.faa");
	my $size = length($seq);
	
	#reading frame 1
	$protein = get_frame($seq, 1);
	$cds = frames2fasta($protein, 0, 1);
	print OUT2 "$cds";

	#reading fram 2
	$protein = get_frame($seq, 2);
	$cds = frames2fasta($protein, 1, 2);
	print OUT2 "$cds";

	#reading frame 3
	$protein = get_frame($seq, 3);
	$cds = frames2fasta($protein, 2, 3);
	print OUT2 "$cds";

	#calculate reverse complement
	my $rev_seq = revcom($seq);

	#reading frame 4
	$protein = get_frame($rev_seq, 1);
	$cds = frames2fasta_revcom($protein, 0, $size, 4);
	print OUT2 "$cds";
	
	#reading frame 5
	$protein = get_frame($rev_seq, 2);
	$cds = frames2fasta_revcom($protein, 1, $size, 5);
	print OUT2 "$cds";
	
	#reading frame 6
	$protein = get_frame($rev_seq, 3);
	$cds = frames2fasta_revcom($protein, 2, $size, 6);
	print OUT2 "$cds";
	
	close OUT2;
	
}
elsif ($aa =~ 'T')
{
	print "These are amino acid sequences\n";
	`cp $filename enterdata.faa`;
}

print "Running EffectorFAM search\n";


#Runs the input sequence file against the effectorFAM HMMs
$result = `hmmscan $path/db/Efam enterdata.faa`;
open (OUT, ">$path/out/Efam.out");
print OUT "$result";
close OUT;


#open the HMM list and stores HMM description in a hash
open (IN, "$path/db/hmm_list.txt") or die "Couldn't open HMM list\n";

while ($line3 = <IN>)
{
	chomp $line3;
	@part = split(/\t/, $line3);
	$model = $part[0];
	$desc = $part[2];
	$anno = $part[1];
	$hash{$model} = $desc;
	$hash2{$model} = $anno;
}

close IN;
	

#opens an output file for the HMM results
open (OUT2, ">effectorfam_results.txt");
 
if ($aa =~ 'T')
{
	print OUT2 "Protein\tDescription\tHMM\tAnnotation\tHMM description\tBit Score\tE Value\tNo. of Domains\tAlignment from\tAlignment to\n";
}
elsif ($aa =~ 'F')
{
	print OUT2 "ORF\tCoordinates\tHMM ID\tAnnotation\tHMM description\tBit Score\tE Value\tNo. of Domains\tAlignment from\tAlignment to\n";
}

#Parser the HMM results and prints the best results
open (IN3, "$path/out/Efam.out") or die "Couldn't open Efam.out\n";
while ($line2 = <IN3>)
{
	chomp $line2;
	if ($line2 =~ /^Query:\s+(\S+)/) # get protein name
	{
		$gene = $1;
		$check = "0"; #Used to ensure only best hit is record
		$check2 = "1"; #checks if HMM work
		$check3 = "0";
	}
	if ($line2 =~ /^Description:\s(.+)/) #get gene name 
	{
		$data = $1;
	}
	if ($line2 =~ /^\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)\s+(\w+)\s+(.+)$/) #matches main results line
	{
		$eValue = $1;
		$bitScore = $2;
		$eValueDom = $4;
		$N = $8;
		$hmm = $9;
		if (($eValue < 0.00001) and ($eValueDom < 0.00001) and ($bitScore > 100) and ($check =~ /0/))
		{
			print OUT2 "$gene\t$data\t$hmm\t$hash2{$hmm}\t$hash{$hmm}\t$bitScore\t$eValue\t$N\t";
			$check = "1";
		}
		else
		{
			next;
		}
	}
	if ($line2 =~ /^\s+\d\s!\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/) #matches the alignment line
	{
		$aliFrom = $8;
		$aliTo = $9;
		if (($3 < 0.00001) and ($1 > 100) and ($check3 =~ /0/))
		{
			print OUT2 "$aliFrom\t$aliTo\n";
			$check3 = "1";
		}
		else
		{
			next;
		}
	}
	else
	{
		next;
	}
}

close IN3;	
close OUT2;
	
#check for error
if ($check2 =~ /1/)
{
	$check2 = "good";
}
else
{
	print "An error has occured. Check sequences for invalid characters\n";
	exit;
}

#if upload sequence is nucleotide generate a genbank table file
if ($aa =~ 'F')
{
	efam2gen("effectorfam_results.tab");
}
	
print "EffectorFAM search complete\n";

`rm enterdata.faa`;

exit;